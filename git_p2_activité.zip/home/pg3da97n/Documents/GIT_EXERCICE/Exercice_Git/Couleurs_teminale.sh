local RED="\[\033[0;31m\]"
local GREEN="\[\033[0;32m\]"
local BLUE="\[\033[0;34m\]"
local PURPLE="\[\033[0;35m\]"
local GRAY="\[\033[0;37m\]"


RED="\[\033[0;31m\]"
GREEN="\[\033[0;32m\]"
BLUE="\[\033[0;34m\]"
PURPLE="\[\033[0;35m\]"
GRAY="\[\033[0;37m\]"
export PS1="${RED}\u${GREEN}@${BLUE}\h${PURPLE}\w${GRAY}$"