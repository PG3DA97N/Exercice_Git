/*
Pour importer des fichier d'un repository git depuis github on utilise la commande git clone:
git clone https://github.com/<nom du user>/<nom du repertoire>

exemple on veut importer la librairie react.git
git clone https://github.com/facebook/react.git

Pur exporter des donner que l'on a crer dans un repertoire git sur notre poste dans github on utilise la commande git remote pour copier notre repository dans le ripository créer sur github.
exemple:
on veut copier un repository dans le repository Hello_world.git que l'on a créer sur Hello_world.git on se place dans le repertoire et l'on tape la commande suivante:
git remote add origin https://github.com/PG3DA97N/Hello_world.git


Pour ajouter le code sur github on utilise la commande git push. 
exemple: on veut envoyer dans master. 
git push -u <nom du remote> <nom de la branche>
git push -u origin master
*/